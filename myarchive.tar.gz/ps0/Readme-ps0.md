# PS0: Hello SFML

## Contact
Name:

Section:

Time to Complete:


## Description
Explain what the project is supposed to do.

### Features
Describe what your major decisions were and why you did things that way.

### Issues
What doesn't work.  Be honest.  You might be penalized if you claim something works and it doesn't.

### Extra Feature
Describe anything special you did.  This is required to earn points.


## Integrity
Read the University policy Academic Integrity, and answer the following question:

There are six examples of academic misconduct, labeled (a) through (f). Other than (a), "Seeks to claim credit for the work or efforts of another without authorization or citation," which of these do you think would most apply to this class, and why? Write approx. 100-200 words. Note: there is no single correct answer to this. I am looking for your opinion.


## Acknowledgements
List all sources of help including the instructor or TAs, classmates, and web pages.

### Credits
List where you got any images or other resources.
